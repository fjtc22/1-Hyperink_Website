<?php
include 'functions.php';

require('vendor/autoload.php');
// this will simply read AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY from env vars
$s3 = new Aws\S3\S3Client([
    'version'  => 'latest',
    'region'   => 'eu-south-1',
]);
$bucket = getenv('S3_BUCKET_NAME')?: die('No "S3_BUCKET_NAME" config var in found in env!');

$msg = '';


	if(isset($_POST['update'])){

		$editor=$_POST['editor'];
		$imageName=$_FILES['immagine']['name'];
		//$target = 'IMAGES/' . $imageName;
		//move_uploaded_file($_FILES["immagine"]["tmp_name"], $target);

		if(empty($_FILES['immagine']['name'])){

	  //Query for Insertion
		$data = [
			'id_post' => $_GET['id'],
			'editor' => $editor,
		];

		$sql = "INSERT INTO contenuto (id_post, editor) VALUES (:id_post, :editor)";
		$stmt= $pdo->prepare($sql);
		$stmt->execute($data);

	}else{
		//Query for Insertion
		$data = [
			'id_post' => $_GET['id'],
			'editor' => $editor,
			'immagine' => $imageName,

		];

		$sql = "INSERT INTO contenuto (id_post, editor, imageb) VALUES (:id_post, :editor, :immagine)";
		$stmt= $pdo->prepare($sql);
		$stmt->execute($data);

		$upload = $s3->upload($bucket, $imageName, fopen($_FILES['immagine']['tmp_name'], 'rb'), 'public-read');
	}

		header('Location: preview.php?id=' . $_GET['id']);
		//header('Location: private.php');
	}


?>


<!DOCTYPE html>

<html>
	<head>
		<meta charset="utf-8">
		<title>Aggiungi Elemento</title>
		<link rel="shortcut icon" href="IMG/Hyperink-logo.ico" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="CSS/Style_Private_1280px.css" rel="stylesheet" type="text/css">
		<link href="CSS/Style_Private_960px.css" rel="stylesheet" type="text/css">
		<link href="CSS/Style_Private_720px.css" rel="stylesheet" type="text/css">
		<link href="CSS/Style_Private_mobile.css" rel="stylesheet" type="text/css">
		<link href="CSS/normalize.css" rel="stylesheet" type="text/css">
		<script type="text/javascript" src="JS/modernizr.js"></script>
		<script src="JS/ckeditor5/ckeditor.js"></script>
		<link rel="stylesheet" href="JS/ckeditor5/content-styles.css" type="text/css">
	</head>

	<body>
		<div class="container_create">
			<div class="topnav">
				<a href="preview.php?id=<?php echo $_GET['id']; ?>"><img src="IMG/Back_icon.svg" alt="menu" id="back_icon"></a>
				<img src="IMG/Logo_orizontale.svg" alt="menu" id="hyperink_logo">
			</div>

			<p id="titolo_create">Aggiungi Elemento</p>

			<div class="box_create">
				<form id="form_create" method="post" enctype="multipart/form-data">

					<label class="labels_create">Contenuto del Articolo</label>
					<div class="text_editor">
						<textarea id="main" name="editor" rows="5" cols="50"></textarea>
					</div>

					<input type="file" id="immagine" name="immagine" class="inputs_create_file" accept="image/*">

					<input type="submit" name="update" value="Aggiungi Elemento" class="btn_create">
				</form>
			</div>
		</div>
	</body>

	<script type="text/javascript">
	ClassicEditor.create( document.querySelector( '#main' ), {
		toolbar: {
			items: [
				'heading',
				'|',
				'bold',
				'italic',
				'underline',
				'link',
				'bulletedList',
				'numberedList',
				'|',
				'alignment',
				'outdent',
				'indent',
				'horizontalLine',
				'|',
				'insertTable',
				'blockQuote',
				'-',
				'undo',
				'redo',
				'mediaEmbed',
				'htmlEmbed',
				'code',
				'fontBackgroundColor',
				'fontColor',
				'fontSize',
				'specialCharacters'
			],
			shouldNotGroupWhenFull: true
		},
		language: 'it',
		link: {
			addTargetToExternalLinks: true,
		},
		image: {
			toolbar: [
				'imageTextAlternative',
				'imageStyle:full',
				'imageStyle:side',
				'mediaEmbed'
			]
		},
		table: {
			contentToolbar: [
				'tableColumn',
				'tableRow',
				'mergeTableCells',
				'tableProperties'
			]
		},
		licenseKey: ''
	} )
		.then( editor => {window.editor = editor;} )
		.catch( error => {
			console.error( 'Oops, something went wrong!' );
			console.error( 'Please, report the following error on https://github.com/ckeditor/ckeditor5/issues with the build id and the error stack trace:' );
			console.warn( 'Build id: 7t1fs3s450fl-ev4z8x3r9ppl' );
			console.error( error );
		});
	</script>
</html>
