<?php
session_start();

include 'functions.php';
$message = '';

if(isset($_POST['login'])){
	if(empty($_POST['username']) || empty($_POST['password'])){
		$message = '<label>All fields are required</label>';
	}
	else {
		$query = 'SELECT * FROM users WHERE username = :username AND password = :password';

		$stmt = $pdo->prepare($query);

		$stmt->execute(array('username' => $_POST['username'], 'password' => $_POST['password']));

		$count = $stmt->rowCount();

		if ($count > 0){
			$_SESSION['username'] = $_POST['username'];
			header("location:private.php");
		}
		else{
			echo '<script type="text/javascript">';
			echo 'alert("Wrong Data")';
			echo '</script>';
		}
	}
}
?>

<!DOCTYPE html>

<html>
	<head>
		<meta charset="utf-8">
		<title>Login</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" href="IMG/Hyperink-logo.ico" />
		<link href="CSS/Style_Private_1280px.css" rel="stylesheet" type="text/css">
		<link href="CSS/Style_Private_960px.css" rel="stylesheet" type="text/css">
		<link href="CSS/Style_Private_720px.css" rel="stylesheet" type="text/css">
		<link href="CSS/Style_Private_mobile.css" rel="stylesheet" type="text/css">
		<link href="CSS/normalize.css" rel="stylesheet" type="text/css">
		<script type="text/javascript" src="JS/modernizr.js"></script>
	</head>

	<body>
		<div class="container_login">
			<?php if(isset($message)){echo '<label class="text-danger">'.$message.'</label>';} ?>

			<div class="topnav">
				<a href="index.php"><img src="IMG/home_button.svg" alt="menu" id="back_icon"></a>
				<img src="IMG/Logo_orizontale.svg" alt="menu" id="hyperink_logo">
			</div>

			<p id="titolo_login">Login</p>

			<div class="box_login">
				<form method="post" id="form_login">
					<label class="labels_login">Username</label>

					<input type="text" id="username" name="username" class="inputs_login" required/>

					<label class="labels_login">Password</label>

					<input type="password" id="password" name="password" class="inputs_login" required/>

					<input type="submit" name="login" class="btn_login" value="Login"/>
				</form>
			</div>
		</div>
	</body>
</html>
