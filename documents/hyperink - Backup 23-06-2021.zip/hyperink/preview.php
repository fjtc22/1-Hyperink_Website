<?php
session_start();

include 'functions.php';

if(isset($_SESSION['username'])){
    //echo '<h3>Success,  Welcome - ' .$_SESSION['username']. '</h3>';
} else {
	session_destroy();
    header("location:login.php");
}

$id = $_GET['id'];

$sql = "SELECT * FROM post WHERE id=$id";
$stmt = $pdo->prepare($sql);
$stmt->execute();

$sql_cont = "SELECT * FROM contenuto WHERE id_post=$id";
$stmt_cont = $pdo->prepare($sql_cont);
$stmt_cont->execute();




?>




<!doctype html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Preview</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" href="IMG/Hyperink-logo.ico" />
		<link href="CSS/Style_SinglePage_1280px.css" rel="stylesheet" type="text/css">
		<link href="CSS/Style_SinglePage_960px.css" rel="stylesheet" type="text/css">
		<link href="CSS/Style_SinglePage_720px.css" rel="stylesheet" type="text/css">
		<link href="CSS/Style_SinglePage_mobile.css" rel="stylesheet" type="text/css">
		<link href="CSS/normalize.css" rel="stylesheet" type="text/css">
		<script type="text/javascript" src="JS/modernizr.js"></script>
	</head>

	<body>
		<div class="container">
			<div class="topnav">
				<a href="private.php">
					<img src="IMG/Back_icon.svg" alt="menu" id="back_icon">
				</a>

				<a href="read.php?id=<?php echo $_GET['id']; ?>"> <!-- Questa è il nuovo bottone aggiunto -->
					<img src="IMG/page_button.svg" alt="page" id="page_icon">
				</a>

				<img src="IMG/Logo_orizontale.svg" alt="menu" id="hyperink_logo">
			</div>

			<div class="div-vuoto"></div>

			<div class="Elements">

				<?php $contacts = $stmt->fetchAll(PDO::FETCH_ASSOC);
				foreach($contacts as $contact){
					$image = $contact['image'];?>
				<div class="main_box">
					<h1 class="Titolo_articolo"><?php echo $contact['title'];?></h1>

					<div class="box_IMG">
						<img src="<?php echo 'https://hyperink-images-bucket.s3.eu-south-1.amazonaws.com/'.$image?>" alt="Immagine" id="main_IMG">
					</div>

					<div class="line"></div>

					<p class="Paragrafo_articolo"><?php echo $contact['main'];?></p>
				</div>
				<?php } ?>


				<?php $body_box = $stmt_cont->fetchAll(PDO::FETCH_ASSOC);
							foreach($body_box as $box){
								$imageb = $box['imageb'];?>
				<div class="body_box">
					<h2><?php echo $box['editor'];?></h2>
					<img src="<?php echo 'https://hyperink-images-bucket.s3.eu-south-1.amazonaws.com/'.$imageb ?>" class="box_IMG" onerror="hideimg(this);">
					<button class="modifica">
						<a href="modifica_box.php?id=<?php echo $box['ID'];?>">
							<img src="IMG/edit_button.svg" class="preview_buttons" alt="edit">
						</a>
					</button>
					<button class="ellimina" onClick="deleteme(<?php echo $box['ID'];?>)">
						<a href="#">
							<img src="IMG/delete_button.svg" class="preview_buttons" alt="delete">
						</a>
					</button>
				</div>
				<?php } ?>


			</div>



			<button class="aggiungi_sezione">
				<a href="box.php?id=<?php echo $_GET['id']; ?>">
					<img src="IMG/nuovo_button.svg" class="preview_buttons" alt="aggiungi">
				</a>
			</button>

			<button class="modifica_articolo">
				<a href="update.php?id=<?php echo $_GET['id']; ?>">
					<img src="IMG/imp_button.svg" class="preview_buttons" alt="modifica">
				</a>
			</button>



	<div class="footer"></div>

</div>

</body>
</html>

<script type="text/javascript">

function deleteme(delid){
	if(confirm("Do you want to Delete?")){
		window.location.href="delete_box.php?id=" + delid + '';
		return true;
	}
}

function hideimg(i){
	i.style.display='none';
}
</script>
