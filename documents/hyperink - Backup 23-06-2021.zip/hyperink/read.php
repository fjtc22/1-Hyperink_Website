<?php
  include 'functions.php';

  $id = $_GET['id'];
  $stmt = $pdo->query("SELECT * FROM post WHERE id = $id");
  $sql_cont = "SELECT * FROM contenuto WHERE id_post=$id";
  $stmt_cont = $pdo->prepare($sql_cont);
  $stmt_cont->execute();


 ?>

<!doctype html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Single_Page</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="IMG/Hyperink-logo.ico" />
		<link href="CSS/Style_SinglePage_1280px.css" rel="stylesheet" type="text/css">
		<link href="CSS/Style_SinglePage_960px.css" rel="stylesheet" type="text/css">
		<link href="CSS/Style_SinglePage_720px.css" rel="stylesheet" type="text/css">
		<link href="CSS/Style_SinglePage_mobile.css" rel="stylesheet" type="text/css">
		<link href="CSS/normalize.css" rel="stylesheet" type="text/css">
		<script type="text/javascript" src="JS/modernizr.js"></script>
	</head>

	<body>
		<div class="container">
			<div class="topnav">
				<a href="index.php">
					<img src="IMG/Back_icon.svg" alt="menu" id="back_icon">
				</a>

				<img src="IMG/Logo_orizontale.svg" alt="menu" id="hyperink_logo">
			</div>

			<div class="div-vuoto"></div>

			<div class="Elements">
				<?php while($contacts = $stmt->fetch(PDO::FETCH_OBJ)){
          	$image = $contacts->image;
             ?>
				<h1 class="Titolo_articolo"><?=$contacts->title;?></h1>

				<div class="box_IMG">
          <img src="<?php echo 'https://hyperink-images-bucket.s3.eu-south-1.amazonaws.com/'.$image?>" alt="Immagine" id="main_IMG"/>
				</div>

				<div class="line"></div>

				<p class="Paragrafo_articolo"><?=$contacts->main;?></p>
        <?php } ?>

        <?php while($body_box = $stmt_cont->fetch(PDO::FETCH_OBJ)){?>
        <h2><?=$body_box->editor;?></h2>
        <img src="<?php echo 'https://hyperink-images-bucket.s3.eu-south-1.amazonaws.com/'.$body_box->imageb;?>" alt="Immagine" class="box_image" onerror="hideimg(this);">
        <?php } ?>
			</div>

			<div class="footer"></div>
		</div>
	</body>
</html>

<script type="text/javascript">

function hideimg(i){
	i.style.display='none';
}

</script>
