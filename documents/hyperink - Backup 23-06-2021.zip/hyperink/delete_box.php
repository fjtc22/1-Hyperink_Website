<?php
include 'functions.php';

// Check that the contact ID exists
$stmt = $pdo->prepare('DELETE FROM contenuto WHERE id = ?');
$stmt->execute([$_GET['id']]);

header("Location: private.php");
//header('Location: preview.php?id=' . $_GET['id_post']);

?>
