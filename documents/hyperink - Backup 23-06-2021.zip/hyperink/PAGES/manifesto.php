<!doctype html>
<html>

<head>
<meta charset="UTF-8">
<title>Manifesto</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="text/javascript" src="../JS/modernizr.js"></script>
<link href="../CSS/normalize.css" rel="stylesheet" type="text/css">
<link href="../CSS/Style_SinglePage_1280px.css" rel="stylesheet" type="text/css">
<link href="../CSS/Style_SinglePage_960px.css" rel="stylesheet" type="text/css">
<link href="../CSS/Style_SinglePage_720px.css" rel="stylesheet" type="text/css">
<link href="../CSS/Style_SinglePage_mobile.css" rel="stylesheet" type="text/css">
</head>

<body>

<div class="container">

	<div class="topnav">

		<a href="../index.php">
			<img src="../IMG/Back_icon.svg" alt="menu" id="back_icon">
		</a>

		<img src="../IMG/Logo_orizontale.svg" alt="menu" id="hyperink_logo">

	</div>

	<div class="div-vuoto"></div>

	<div class="Elements">

		<h2>Manifesto</h2>

		<p>Digitalizzare tutto è possibile. Stampare tutto, anche.</p>

		<p>La transizione digitale miete vittime ogni secondo. Lascia indietro persone e storie che con poche risorse e conoscenze tecniche non possono contribuire al grande lascito. I veri cambiamenti non sono mai indolore, altrimenti non sarebbero tali.</p>

		<p>Il pluralismo è un fattore determinante del principio di equità,  e non di uguaglianza. Plurale significa in questo senso, anche privo di giudizio esterno, di controllo, di censura.</p>

		<p>La parola scritta tramandata è lo strumento attraverso il quale generazioni di persone hanno costruito tutto quello che ci circonda. L’artificio è dunque da considerarsi parte integrante dell’ambiente, e non estraneo ad esso.</p>

		<p>C’ho che è fisico può diventare digitale, ed entrambi saranno sempre e simultaneamente parte della biologia dell’ecosistema cui appartengono.</p>

		<p>Contenuti gratuiti e registrazione obbligatoria, è un ossimoro.</p>

		<p>Le persone sono persone, gli utenti sono utenti.</p>

	</div>

	<div class="footer_privacy"></div>

</div>

</body>
</html>
