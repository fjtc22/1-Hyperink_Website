<?php
  $host = 'eu-cdbr-west-01.cleardb.com';
  $user = 'bc85f5b1edde62';
  $password = '2d825752';
  $db_name = 'heroku_092d91f3ce171e8';

  //SET DSN
  $dsn = 'mysql:host='. $host .';dbname='. $db_name;
  
  //CREATE PDO INSTANCE
  try{
   return $pdo = new PDO($dsn, $user, $password);
  } 

  catch(PDOException $exception){
	  // If there is an error with the connection, stop the script and display the error.
	  exit('Failed to connect to database!');
  }
?>