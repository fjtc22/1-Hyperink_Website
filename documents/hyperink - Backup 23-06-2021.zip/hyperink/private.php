<?php
session_start();

include 'functions.php';

if(isset($_SESSION['username'])){
    //echo '<h3>Success,  Welcome - ' .$_SESSION['username']. '</h3>';
} else {
	session_destroy();
    header("location:login.php");
}

$stmt = $pdo->query('SELECT * FROM post');
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Area Privata</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" href="IMG/Hyperink-logo.ico" />
		<link href="CSS/Style_Private_1280px.css" rel="stylesheet" type="text/css">
		<link href="CSS/Style_Private_960px.css" rel="stylesheet" type="text/css">
		<link href="CSS/Style_Private_720px.css" rel="stylesheet" type="text/css">
		<link href="CSS/Style_Private_mobile.css" rel="stylesheet" type="text/css">
		<link href="CSS/normalize.css" rel="stylesheet" type="text/css">
		<script type="text/javascript" src="JS/modernizr.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	</head>

	<body>
		<div class="container_private">
			<div class="topnav">
				<a href="index.php" target="_blank"><img src="IMG/home_button.svg" alt="menu" id="home_icon"></a>
				<img src="IMG/Logo_orizontale.svg" alt="menu" id="hyperink_logo">
			</div>

			<p id="titolo_private">Area Privata</p>

			<a href="create.php"><button type="button" class="btn_crea">Crea un nuovo articolo</button></a>

			<a href="logout.php"><button type="button" class="btn_out">Logout</button></a>

			<div class="box_private">
				<table>
					<tr>
						<th>Titolo del Articolo</th>
						<th>Categoria</th>
						<th>Creato il </th>
						<th>Azioni</th>
					</tr>

					<?php while($contacts = $stmt->fetch(PDO::FETCH_OBJ)){?>
					<tr>
						<td><?=$contacts->title; ?></td>
						<td><?=$contacts->category; ?></td>
						<td><?=$contacts->created; ?></td>
						<td>
							<a href="preview.php?id=<?=$contacts->ID?>">
								<button type="button" class="btn_modifica">Modifica</button>
							</a>

							<button type="button" class="btn_ellimina" onClick="deleteme(<?=$contacts->ID?>)">Elimina</button>
						</td>
					</tr>
					<?php } ?>
				</table>
			</div>
		</div>
	</body>

	<script type="text/javascript">
		function deleteme(delid){
			if(confirm("Do you want to Delete?")){
				window.location.href="delete.php?id=" + delid + '';
				return true;
			}
		}
	</script>
</html>
