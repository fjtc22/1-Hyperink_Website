<?php
include 'functions.php';

require('vendor/autoload.php');
// this will simply read AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY from env vars
$s3 = new Aws\S3\S3Client([
    'version'  => 'latest',
    'region'   => 'eu-south-1',
]);
$bucket = getenv('S3_BUCKET_NAME')?: die('No "S3_BUCKET_NAME" config var in found in env!');

$msg = '';

if(isset($_GET['id'])){
	if(isset($_POST['update'])){

		// Posted Values
		$title=$_POST['title'];
		$category=$_POST['category'];
		$preview=$_POST['preview'];
		$main=$_POST['main'];
		$created = $_POST['created'];

		$imageName=$_FILES['immagine']['name'];
		$imageNameTemp=$_FILES['immagine']['tmp_name'];

		if(empty($_FILES['immagine']['name'])){
			// Query for Insertion
			$data = [
				'title' => $title,
				'category' => $category,
				'preview' => $preview,
				'main' => $main,
				'id' => $_GET['id'],
				'created' => $created,
			];

			$sql="UPDATE post SET title=:title, category=:category, preview=:preview, main=:main, created=:created WHERE id=:id";
			//Prepare Query for Execution
			$stmt = $pdo->prepare($sql);

			// Query Execution
			$stmt->execute($data);

		} else{

			// Query for Insertion
			$data = [
				'title' => $title,
				'category' => $category,
				'preview' => $preview,
				'main' => $main,
				'id' => $_GET['id'],
				'created' => $created,
				'immagine' => $imageName,
			];

			$sql="UPDATE post SET title=:title, category=:category, preview=:preview, main=:main, created=:created, image=:immagine WHERE id=:id";
			//Prepare Query for Execution
			$stmt = $pdo->prepare($sql);

			// Query Execution
			$stmt->execute($data);
			$upload = $s3->upload($bucket, $imageName, fopen($_FILES['immagine']['tmp_name'], 'rb'), 'public-read');
		}


		header('Location: preview.php?id=' . $_GET['id']);
  }

	$stmt = $pdo->prepare('SELECT * FROM post WHERE id = ?');
	$stmt->execute([$_GET['id']]);
	$contact = $stmt->fetch(PDO::FETCH_ASSOC);

}
?>

<!DOCTYPE html>

<html>
	<head>
		<meta charset="utf-8">
		<title>Update</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" href="IMG/Hyperink-logo.ico" />
		<link href="CSS/Style_Private_1280px.css" rel="stylesheet" type="text/css">
		<link href="CSS/Style_Private_960px.css" rel="stylesheet" type="text/css">
		<link href="CSS/Style_Private_720px.css" rel="stylesheet" type="text/css">
		<link href="CSS/Style_Private_mobile.css" rel="stylesheet" type="text/css">
		<link href="CSS/normalize.css" rel="stylesheet" type="text/css">
		<script type="text/javascript" src="JS/modernizr.js"></script>
		<script src="JS/ckeditor5/ckeditor.js"></script>
		<link rel="stylesheet" href="JS/ckeditor5/content-styles.css" type="text/css">
	</head>

	<body>
		<div class="container_create">
			<div class="topnav">
				<a href="preview.php?id=<?php echo $_GET['id']; ?>"><img src="IMG/Back_icon.svg" alt="menu" id="back_icon"></a>
				<img src="IMG/Logo_orizontale.svg" alt="menu" id="hyperink_logo">
			</div>

			<p id="titolo_create">Impostazione Pagina</p>

			<div class="box_create">
				<form action="update.php?id=<?php echo $_GET['id']; ?>" method="post" id="form_create" enctype="multipart/form-data">

					<label class="labels_create">Data</label>
					<input type="datetime-local" name="created" class="inputs_create" id="myDatetimeField" value="<?=$contact['created']?>">

					<label class="labels_create">Titolo del Articolo</label>
					<input type="text" name="title" class="inputs_create" id="title" value="<?=$contact['title']?>">

					<label class="labels_create">Categoria</label>
					<input type="text" name="category" class="inputs_create" id="cat" value="<?=$contact['category']?>">

					<label class="labels_create">Descrizione</label>
					<textarea type="text" name="preview" id="preview" class="inputs_create" row="5" col="50" onkeyup ="limite_caratteri()"><?=$contact['preview']?></textarea>


					<label class="labels_create">Contenuto del Articolo</label>
					<div class="text_editor">
						<textarea id="main" name="main" rows="5" cols="50"><?=$contact['main']?></textarea>
					</div>

					<input type="file" id="immagine" name="immagine" class="inputs_create_file" accept="image/*"></span>

					<input type="submit" name="update" value="Salva Modifiche" class="btn_create">
				</form>
			</div>

			<?php if ($msg): ?><p id="messaggio_create"><?=$msg?></p><?php endif; ?>
		</div>
	</body>

	<script type="text/javascript">

	function limite_caratteri() {
			var areaditesto = document.getElementById("preview");
			var max = 210;

			if ( areaditesto.value.length > max){
				areaditesto.value = areaditesto.value.substr(0, max);
				alert("Inserire massimo " + max + " caratteri");
			}
		}

	window.addEventListener("load", function() {
    var now = new Date();
    var utcString = now.toISOString().substring(0,19);
    var year = now.getFullYear();
    var month = now.getMonth() + 1;
    var day = now.getDate();
    var hour = now.getHours();
    var minute = now.getMinutes();

    var localDatetime = year + "-" +
                      (month < 10 ? "0" + month.toString() : month) + "-" +
                      (day < 10 ? "0" + day.toString() : day) + "T" +
                      (hour < 10 ? "0" + hour.toString() : hour) + ":" +
                      (minute < 10 ? "0" + minute.toString() : minute);
    var datetimeField = document.getElementById("myDatetimeField");
    datetimeField.value = localDatetime;
});

	ClassicEditor.create( document.querySelector( '#main' ), {
		toolbar: {
			items: [
				'heading',
				'|',
				'bold',
				'italic',
				'underline',
				'link',
				'bulletedList',
				'numberedList',
				'|',
				'alignment',
				'outdent',
				'indent',
				'horizontalLine',
				'|',
				'insertTable',
				'blockQuote',
				'-',
				'undo',
				'redo',
				'mediaEmbed',
				'htmlEmbed',
				'code',
				'fontBackgroundColor',
				'fontColor',
				'fontSize',
				'specialCharacters'
			],
			shouldNotGroupWhenFull: true
		},
		language: 'it',
		link: {
			addTargetToExternalLinks: true,
		},
		image: {
			toolbar: [
				'imageTextAlternative',
				'imageStyle:full',
				'imageStyle:side',
				'mediaEmbed'
			]
		},
		table: {
			contentToolbar: [
				'tableColumn',
				'tableRow',
				'mergeTableCells',
				'tableProperties'
			]
		},
		licenseKey: ''
	} )
		.then( editor => {window.editor = editor;} )
		.catch( error => {
			console.error( 'Oops, something went wrong!' );
			console.error( 'Please, report the following error on https://github.com/ckeditor/ckeditor5/issues with the build id and the error stack trace:' );
			console.warn( 'Build id: 7t1fs3s450fl-ev4z8x3r9ppl' );
			console.error( error );
		});
	</script>
</html>
