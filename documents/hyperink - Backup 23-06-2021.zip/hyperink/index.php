<?php
include 'functions.php';

//Search box

$search = $_GET['query'];
$limit = 6;

//total number record

$countsql = $pdo->prepare("SELECT COUNT(id) FROM post");
$countsql->execute();
$row = $countsql->fetch();
$num_records = $row[0];
$num_links = ceil($num_records/$limit);
$page = $_GET['start'];

if (!isset($_GET['start'])) {
	$page = 1;
}
else{
	$page = $_GET['start'];
}

$start = ($page-1) * $limit;
$stmt = $pdo->query("SELECT * FROM post WHERE `title` LIKE '%$search%' or 'category' LIKE '%$search%' ORDER BY created DESC LIMIT $start, $limit");
$stmt->execute();

?>

<!doctype html>

<html>
	<head>
		<meta charset="utf-8">
		<title>HomePage</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="JS/cookieconsent-3.1.1/build/cookieconsent.min.css">
		<script type="text/javascript" src="JS/cookieconsent-3.1.1/build/cookieconsent.min.js"></script>
		<link rel="shortcut icon" href="IMG/Hyperink-logo.ico" />
		<link href="CSS/Style_HomePage_1280px.css" rel="stylesheet" type="text/css">
		<link href="CSS/Style_HomePage_960px.css" rel="stylesheet" type="text/css">
		<link href="CSS/Style_HomePage_720px.css" rel="stylesheet" type="text/css">
		<link href="CSS/Style_HomePage_mobile.css" rel="stylesheet" type="text/css">
		<link href="CSS/normalize.css" rel="stylesheet" type="text/css">
		<script type="text/javascript" src="JS/modernizr.js"></script>
		<meta name="Franco_Ticona" description="Fron-end_development_HTML_CSS_JAVASCRIPT">
		<meta name="Arianna_Parisi" description="Back-end_development_PHP_MYSQL">
	</head>

	<body>
		<div class="Contenitor">
			<div id="icona_menu" class="menu" onclick="animazionebutton(this)">
				<div class="bar1"></div>
				<div class="bar2"></div>
				<div class="bar3"></div>
			</div>

			<form class="search" method="get" action="index.php">
				<input type="search" id="searchbox" name="query" placeholder="Ricerca nel sito...">
				<img src="IMG/Search_Icon.svg" onclick="animazionesearch()" alt="Search" id="icona_search">
			</form>

			<div id="topnav">
				<div id="lista">
					<a href="PAGES/manifesto.php" class="link" id="etichetta_manifesto">Manifesto</a>
					<a href="#partners" onClick="patners()" id="etichetta_partners">Partners</a>
					<a href="#newsletter" onClick="newsletter()" id="etichetta_newsletter">Newsletter</a>
				</div>
			</div>

			<div id="Newsletter">
				<form method="post" action="http://a1e4h.emailsp.com/frontend/xmlsubscribe.aspx" target="_top">
					<div class="contenitore_newsletter">
						<input type="text" placeholder="Your email address" name="email" required id="input_email">
						<input type="hidden" name="list" value="7">
						<input type="hidden" name="confirm" value="0">
					</div>

					<div class="contenitore_newsletter">
						<input type="submit" value="Subscribe" id="submit_email">
					</div>
				</form>
			</div>

			<div id="Patners">
				<div id="Patners_box">
					<a href="http://designlibrary.it/" target="_blank" id="link_design">
						<img src="IMG/Design_Library_Logo.svg" alt="Design Library Logo" class="Patners_logos" id="Design_Library">
					</a>
					<a href="https://www.siam1838.it/" target="_blank" id="link_siam">
						<img src="IMG/Siam_1838_Logo.svg" alt="Design Library Logo" class="Patners_logos" id="Siam1828">
					</a>
					<a href="https://fmed.ktu.edu/dc/" target="_blank" id="link_ktu">
						<img src="IMG/KTU_Logo.svg" alt="Design Library Logo" class="Patners_logos" id="KTU">
					</a>
					<a href="#" id="link_union">
						<img src="IMG/Union_Logo.svg" alt="Design Library Logo" class="Patners_logos" id="Union">
					</a>
					<a href="https://designfriends.org/en/" target="_blank" id="link_friends">
						<img src="IMG/Design_Friends_Logo.svg" alt="Design Library Logo" class="Patners_logos" id="Design_Friends">
					</a>
				</div>
			</div>

			<div id="top-vuoto"></div>

			<div class="Contenuto">
				<div class="main_box">
					<a href="index.php"><img src="./IMG/Main_Logo.svg" id="main_logo"></a>
				</div>

				<div class="separator"></div>

				<div class="Elementi">
					<?php while($contacts = $stmt->fetch(PDO::FETCH_OBJ)){
											$image = $contacts->image;
					?>


					<div class="colonne">
						<div class="Cards">
							<a class="links" href="read.php?id=<?=$contacts->ID; ?>">
								<div class="box_immagine">
									<img src="<?php echo 'https://hyperink-images-bucket.s3.eu-south-1.amazonaws.com/'.$image?>" alt="Immagine" class="immagine_post"/>
								</div>
								<div class="Categorie">
									<p class="Testo_categorie"><?=$contacts->category?></p>
								</div>

								<div class="testo_contenuto">
									<p class="titolo_card"><?=$contacts->title; ?></p>
									<textarea class="Testo_preview" readonly><?=$contacts->preview?></textarea>
									<p class="altro">[READ]</p>
								</div>
							</a>
						</div>
					</div>
					<?php } ?>
			</div>
			</div>

			<div class="pages_list">
				<?php for($i=1; $i<=$num_links; $i++){ echo '<a href="index.php?start='.$i.'"><p class="pages_number">'.$i.'</p></a> '; }?>
			</div>

			<div class="returntop">
				<button onclick="topFunction()" id="return_button">
					<img src="IMG/Back_icon.svg" alt="Top" id="iconatop">
				</button>
			</div>

			<div class="footer">
				<p class="testo_copyright">Copyrights – 2021 hyperink.it by Hyperink. All rights reserved</p>

				<div class="links_footer">
					<a href="PAGES/privacy.php"><p class="testo_footer">Privacy Policy</p></a>
				</div>
			</div>
		</div>
	</body>



	<script>
		window.cookieconsent.initialise({
			container: document.getElementById("content"),
			palette:{
				popup: {background: "rgba(30,30,30,1)"},
				button: {background: "#4646FF"},
			},
			revokable:false,
			onStatusChange: function(status) {
				console.log(this.hasConsented() ? 'enable cookies' : 'disable cookies');
			},
			law: {
				regionalLaw: false,
			},
			location: true,
		});

		var menu;
		var d = window.matchMedia("(max-width: 719px)");
		resize(d);
		d.addListener(resize);

		function resize(d) {
			var x = document.getElementById("topnav");
			var icona = document.getElementById("icona_menu");
			var box = document.getElementById("Newsletter");
			var patners = document.getElementById("Patners");
			var searchbox = document.getElementById("searchbox");
			var searchicon = document.getElementById("icona_search");

			if (d.matches) {
				if (x.style.maxWidth === "100vw") {
					x.style.maxWidth = "0px";
				}
				x.style.maxWidth = "0px";
				box.style.opacity = "0";
				box.style.zIndex = "-1";
				patners.style.opacity = "0";
				patners.style.zIndex = "-2";
				icona.classList.remove("change");
				searchicon.style.opacity = "1";
				searchicon.style.zIndex = "0";
				menu = 1;
			}
			else {
				if (x.style.maxHeight === "400px") {
					x.style.maxHeight = "0px";
				}
				x.style.maxHeight = "0px";
				box.style.opacity = "0";
				box.style.zIndex = "-1";
				patners.style.opacity = "0";
				patners.style.zIndex = "-2";
				icona.classList.remove("change");
				searchicon.style.opacity = "1";
				searchicon.style.zIndex = "0";
				menu = 2;
			}
		}

		function animazionebutton() {

			var b = document.getElementById("icona_menu");
			var x = document.getElementById("topnav");
			var box = document.getElementById("Newsletter");
			var patners = document.getElementById("Patners");
			var searchbox = document.getElementById("searchbox");
			var searchicon = document.getElementById("icona_search");
			var etichetta_newsletter = document.getElementById("etichetta_newsletter");
			var etichetta_partners = document.getElementById("etichetta_partners");
			var etichetta_manifesto = document.getElementById("etichetta_manifesto");

			b.classList.toggle("change");

			if (menu == 1){
				x.style.maxHeight = "none";

				if (x.style.maxWidth === "100vw") {
					document.body.classList.remove('lock-scroll');
					x.style.maxWidth = "0px";
					box.style.opacity = "0";
					box.style.zIndex = "-1";
					patners.style.opacity = "0";
					patners.style.zIndex = "-2";
					searchbox.style.zIndex = "0";
					searchicon.style.opacity = "1";
					searchicon.style.zIndex = "0";
					etichetta_newsletter.style.opacity = "0.8";
					etichetta_partners.style.opacity = "0.8";
					etichetta_manifesto.style.opacity = "0.8";
				}
				else {
					document.body.scrollTop = 0;
					document.documentElement.scrollTop = 0;
					document.body.classList.add('lock-scroll');
					searchbox.style.opacity = "0";
					searchbox.style.zIndex = "-5";
					searchicon.style.opacity = "0";
					searchicon.style.zIndex = "-5";
					x.style.maxWidth = "100vw";
				}
			}

			if (menu == 2){
				x.style.maxWidth = "none";

				if (x.style.maxHeight === "400px") {
					x.style.maxHeight = "0px";
					box.style.opacity = "0";
					box.style.zIndex = "-1";
					patners.style.opacity = "0";
					patners.style.zIndex = "-2";
					searchbox.style.zIndex = "0";
					searchicon.style.opacity = "1";
					searchicon.style.zIndex = "0";
					etichetta_newsletter.style.opacity = "0.8";
					etichetta_partners.style.opacity = "0.8";
					etichetta_manifesto.style.opacity = "0.8";
				}
				else {
					searchbox.style.opacity = "0";
					searchbox.style.zIndex = "-5";
					searchicon.style.opacity = "0";
					searchicon.style.zIndex = "-5";
					x.style.maxHeight = "400px";
				}
			}
		}

		function newsletter() {
			var box = document.getElementById("Newsletter");
			var patners = document.getElementById("Patners");
			var etichetta_newsletter = document.getElementById("etichetta_newsletter");
			var etichetta_partners = document.getElementById("etichetta_partners");
			var etichetta_manifesto = document.getElementById("etichetta_manifesto");

			if (box.style.opacity === "1") {
				box.style.opacity = "0";
				box.style.zIndex = "-1";
				etichetta_newsletter.style.opacity = "0.8";
				etichetta_partners.style.opacity = "0.8";
				etichetta_manifesto.style.opacity = "0.8";
			}
			else {
				box.style.zIndex = "0";
				box.style.opacity = "1";
				patners.style.opacity = "0";
				patners.style.zIndex = "-2";
				etichetta_newsletter.style.opacity = "1";
				etichetta_partners.style.opacity = "0.5";
				etichetta_manifesto.style.opacity = "0.5";
			}
		}

		function patners() {
			var box = document.getElementById("Newsletter");
			var patners = document.getElementById("Patners");
			var etichetta_partners = document.getElementById("etichetta_partners");
			var etichetta_newsletter = document.getElementById("etichetta_newsletter");
			var etichetta_manifesto = document.getElementById("etichetta_manifesto");

			if (patners.style.opacity === "1") {
				patners.style.opacity = "0";
				patners.style.zIndex = "-2";
				etichetta_newsletter.style.opacity = "0.8";
				etichetta_partners.style.opacity = "0.8";
				etichetta_manifesto.style.opacity = "0.8";
			}
			else {
				patners.style.zIndex = "0";
				patners.style.opacity = "1";
				box.style.opacity = "0";
				box.style.zIndex = "-1";
				etichetta_newsletter.style.opacity = "0.5";
				etichetta_partners.style.opacity = "1";
				etichetta_manifesto.style.opacity = "0.5";
			}
		}

		function animazionesearch(){
			var search = document.getElementById("searchbox");

			if (search.style.opacity === "1"){
				search.style.opacity = "0";
				search.style.zIndex = "-1";
			}
			else {
				search.style.opacity = "1";
				search.style.zIndex = "0";
			}
		}

		function topFunction() {
			document.body.scrollTop = 0;
			document.documentElement.scrollTop = 0;
		}
	</script>

</html>
