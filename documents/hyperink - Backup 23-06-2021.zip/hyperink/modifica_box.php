<?php
include 'functions.php';
require('vendor/autoload.php');
// this will simply read AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY from env vars
$s3 = new Aws\S3\S3Client([
    'version'  => 'latest',
    'region'   => 'eu-south-1',
]);
$bucket = getenv('S3_BUCKET_NAME')?: die('No "S3_BUCKET_NAME" config var in found in env!');

$msg = '';

if(isset($_GET['id'])){
	if(isset($_POST['update'])){

		//Posted Values
		$editor=$_POST['editor'];
		$imageName=$_FILES['immagine']['name'];

		if(empty($_FILES['immagine']['name'])){

	  //Query for Insertion
		$data = [
			'id' => $_GET['id'],
			'editor' => $editor,
		];

	  $sql = "UPDATE contenuto SET editor=:editor WHERE id=:id";
		$stmt= $pdo->prepare($sql);
		$stmt->execute($data);

	} else {

		//Query for Insertion
		$data = [
			'id' => $_GET['id'],
			'editor' => $editor,
			'immagine' => $imageName,
		];

	  $sql = "UPDATE contenuto SET editor=:editor, imageb=:immagine WHERE id=:id";
		$stmt= $pdo->prepare($sql);
		$stmt->execute($data);

		$upload = $s3->upload($bucket, $imageName, fopen($_FILES['immagine']['tmp_name'], 'rb'), 'public-read');
	}

	  header('Location: private.php');

	}

	$stmt_sub = $pdo->prepare('SELECT * FROM contenuto WHERE id = ?');
	$stmt_sub->execute([$_GET['id']]);

	$sub = $stmt_sub->fetch(PDO::FETCH_ASSOC);


}
?>


<!DOCTYPE html>

<html>
	<head>
		<meta charset="utf-8">
		<title>Modifica Elemento</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" href="IMG/Hyperink-logo.ico" />
		<link href="CSS/Style_Private_1280px.css" rel="stylesheet" type="text/css">
		<link href="CSS/Style_Private_960px.css" rel="stylesheet" type="text/css">
		<link href="CSS/Style_Private_720px.css" rel="stylesheet" type="text/css">
		<link href="CSS/Style_Private_mobile.css" rel="stylesheet" type="text/css">
		<link href="CSS/normalize.css" rel="stylesheet" type="text/css">
		<script type="text/javascript" src="JS/modernizr.js"></script>
		<script src="JS/ckeditor5/ckeditor.js"></script>
		<link rel="stylesheet" href="JS/ckeditor5/content-styles.css" type="text/css">
	</head>

	<body>
		<div class="container_create">
			<div class="topnav">
				<a href="private.php"><img src="IMG/Back_icon.svg" alt="menu" id="back_icon"></a>
				<img src="IMG/Logo_orizontale.svg" alt="menu" id="hyperink_logo">
			</div>

			<p id="titolo_create">Modifica Elemento</p>

			<div class="box_create">
				<form id="form_create" method="post" enctype="multipart/form-data">

					<label class="labels_create">Contenuto del Articolo</label>
					<div class="text_editor">
						<textarea id="main" name="editor" rows="5" cols="50"><?=$sub['editor']?></textarea>
					</div>

					<input type="file" id="immagine" name="immagine" class="inputs_create_file" accept="image/*">
					<input type="submit" name="update" value="Modifica Elemento" class="btn_create">
				</form>
			</div>
		</div>
	</body>

	<script type="text/javascript">
	ClassicEditor.create( document.querySelector( '#main' ), {
		toolbar: {
			items: [
				'heading',
				'|',
				'bold',
				'italic',
				'underline',
				'link',
				'bulletedList',
				'numberedList',
				'|',
				'alignment',
				'outdent',
				'indent',
				'horizontalLine',
				'|',
				'insertTable',
				'blockQuote',
				'-',
				'undo',
				'redo',
				'mediaEmbed',
				'htmlEmbed',
				'code',
				'fontBackgroundColor',
				'fontColor',
				'fontSize',
				'specialCharacters'
			],
			shouldNotGroupWhenFull: true
		},
		language: 'it',
		link: {
			addTargetToExternalLinks: true,
		},
		image: {
			toolbar: [
				'imageTextAlternative',
				'imageStyle:full',
				'imageStyle:side',
				'mediaEmbed'
			]
		},
		table: {
			contentToolbar: [
				'tableColumn',
				'tableRow',
				'mergeTableCells',
				'tableProperties'
			]
		},
		licenseKey: ''
	} )
		.then( editor => {window.editor = editor;} )
		.catch( error => {
			console.error( 'Oops, something went wrong!' );
			console.error( 'Please, report the following error on https://github.com/ckeditor/ckeditor5/issues with the build id and the error stack trace:' );
			console.warn( 'Build id: 7t1fs3s450fl-ev4z8x3r9ppl' );
			console.error( error );
		});
	</script>
</html>
